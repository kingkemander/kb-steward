#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""合并 AI 补齐结果 → L3 终稿索引

规则：
- subject：AI 抄到的机构名/项目名优先（已做原文校验），否则保留规则层结果
- date：AI 明确日期优先，否则保留
- jd：AI 置信 ≥0.6 才覆盖
- 只补不猜：AI 为空不动原值
"""
import argparse
import collections
import json
import os
import categories
import re

LABEL = categories.LABEL()
WORD = categories.WORD()


def clean(s, n):
    s = re.sub(r"[_/\\:*?\"<>|]+", "-", s or "")
    return re.sub(r"\s+", "", s)[:n]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    OUT = os.path.abspath(args.out)

    pkg = json.load(open(os.path.join(OUT, "个人索引包-L2.json"), encoding="utf-8"))
    items = pkg["items"]
    cache_path = os.path.join(OUT, "14-AI补齐缓存.json")
    cache = json.load(open(cache_path, encoding="utf-8")) if os.path.isfile(cache_path) else {}
    # 档3 视觉解析结果（纯图 PPT / 扫描 PDF / 证照图片）
    vision_path = os.path.join(OUT, "14b-视觉解析缓存.json")
    vision = json.load(open(vision_path, encoding="utf-8")) if os.path.isfile(vision_path) else {}

    dir_map = {}
    for x in items:
        dir_map.setdefault(os.path.dirname(x["source_path"]), []).append(x)

    changed = {"subject": 0, "date": 0, "jd": 0}
    for it in items:
        ai = cache.get(it["source_path"]) or {}
        if ai.get("mode") == "skipped":
            continue
        if ai.get("subject") and not it["subject"]:
            it["subject"] = ai["subject"]
            it["subject_source"] = "AI-全文"
            it["subject_type"] = ai.get("subject_type") or ""
            changed["subject"] += 1
        if ai.get("date") and (it["date"] in ("", "日期待补") or len(str(ai["date"])) > len(str(it["date"]))):
            it["date"] = ai["date"]
            it["date_source"] = "AI-全文"
            changed["date"] += 1
        try:
            conf = float(ai.get("confidence") or 0)
        except Exception:
            conf = 0
        if ai.get("jd") and ai["jd"] in LABEL and conf >= 0.6 and ai["jd"] != it["jd_code"]:
            it["jd_code"] = ai["jd"]
            it["category"] = f'{ai["jd"]} {LABEL[ai["jd"]]}'
            it["category_word"] = WORD[ai["jd"]]
            it["ai_confidence"] = conf
            changed["jd"] += 1

        # 档3 视觉结果（无正文文件的真正信息来源；覆盖「通用」兜底 / 空值 / 判不出的类目）
        v = vision.get(it["source_path"]) or {}
        if v.get("sensitive"):
            it["flags"] = list(it.get("flags", [])) + ["S级-视觉判敏感"]
            it["upload"] = "禁上传"
        if v.get("subject"):
            vc = float(v.get("confidence") or 0)
            is_generic = it["subject"] in ("通用", "") or not it["subject"]
            if is_generic or vc >= 0.5:
                it["subject"] = v["subject"]
                it["subject_source"] = "VLM-视觉"
                it["subject_type"] = v.get("subject_type") or ""
                changed["subject"] += 1
        if v.get("date") and it["date"] in ("", "日期待补"):
            it["date"] = v["date"]
            it["date_source"] = "VLM-视觉"
            changed["date"] += 1
        vc2 = float(v.get("confidence") or 0)
        if v.get("jd") and v["jd"] in LABEL and vc2 >= 0.6 and it["jd_code"] == "00.03":
            it["jd_code"] = v["jd"]
            it["category"] = f'{v["jd"]} {LABEL[v["jd"]]}'
            it["category_word"] = WORD[v["jd"]]
            it["ai_confidence"] = vc2
            it["jd_source"] = "VLM-视觉"
            changed["jd"] += 1
        if v.get("desc"):
            it["vision_desc"] = v["desc"]

        # 邻居投票兜底：本份判不出（00.03 或低置信），但同目录多数已明确 → 采用多数
        if it["jd_code"] == "00.03" and conf < 0.5:
            sib = dir_map.get(os.path.dirname(it["source_path"]), [])
            votes = collections.Counter(
                x["jd_code"] for x in sib
                if x is not it and x["jd_code"] != "00.03")
            if votes:
                top, n_top = votes.most_common(1)[0]
                known = sum(votes.values())
                if n_top >= 3 and n_top / max(known, 1) >= 0.7 and top[:2] != "00":
                    it["jd_code"] = top
                    it["category"] = f"{top} {LABEL[top]}"
                    it["category_word"] = WORD[top]
                    it["ai_confidence"] = round(n_top / max(known, 1), 2)
                    it["jd_source"] = f"同目录多数 {n_top}/{known}"
                    changed["jd"] += 1
                    changed["dir_vote"] = changed.get("dir_vote", 0) + 1

        # 类别词必须跟着最终抽屉走，否则会出现「规则_」却归在待复核这种错配
        it["category_word"] = WORD.get(it["jd_code"], it.get("category_word") or "文件")

        stem = os.path.splitext(it["file_name"])[0]
        c = clean(it["category_word"], 12) or "文件"
        s = clean(it["subject"], 30) if it["subject"] else "主体待补"
        n = clean(stem, 40)
        d = it["date"] if it["date"] not in ("", "日期待补") else "日期待补"
        name = f"{c}_{s}_{n}_{d}{it['ext']}"
        if len(name) > 100:
            n = n[:max(6, len(n) - (len(name) - 100))]
            name = f"{c}_{s}_{n}_{d}{it['ext']}"
        it["suggested_name"] = name

    pkg["layer"] = "L3"
    pkg["summary"].update({
        "ai_covered": len(cache),
        "ai_changed_subject": changed["subject"],
        "ai_changed_date": changed["date"],
        "ai_changed_jd": changed["jd"],
        "dir_vote": changed.get("dir_vote", 0),
        "no_subject_final": sum(1 for i in items if not i["subject"]),
        "named_final": sum(1 for i in items if i["suggested_name"]),
    })
    json.dump(pkg, open(os.path.join(OUT, "个人索引包-L3.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print(json.dumps(pkg["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
